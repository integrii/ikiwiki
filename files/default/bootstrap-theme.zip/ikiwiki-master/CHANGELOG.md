ikiwiki CHANGELOG
=================

1.0.0
-----
- Eric Greer - Initial release of ikiwiki

