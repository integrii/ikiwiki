name             'ikiwiki'
maintainer       'integrii'
maintainer_email 'EricGreer@gmail.com'
license          'All rights reserved'
description      'Installs ikiwiki and the bootstrap 3 theme'
long_description IO.read(File.join(File.dirname(__FILE__), 'README.md'))
version          '1.0.0'
depends		 'yum-epel'
