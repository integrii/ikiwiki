ikiwiki-bootstrap-theme
=======================

Twitter bootstrap theme for ikiwiki

Usage
-----

```
cd ~
git clone git@github.com:ramseydsilva/ikiwiki-bootstrap-theme.git

# edit wiki.setup and add
templatedir: ~/ikiwiki-bootstrap-theme

# Recompile wiki
ikiwiki --setup wiki.setup

# Install your own logo at /logo.png in your webroot
```

Issues
------

This theme is a WIP and has been flushed out only for the main pages/most commonly used options. If you notice that it breaks any particular page or feature, please report it [here] and we can fix it.

[here]: https://github.com/ramseydsilva/ikiwiki-bootstrap-theme/issues
